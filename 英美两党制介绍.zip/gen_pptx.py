#!/usr/bin/env python3
"""
英美两党制 — PPT 生成脚本（含淡出过渡）
运行: pip install python-pptx && python gen_pptx.py
输出: assets/英美两党制.pptx
"""

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE
from lxml import etree
from pptx.oxml.ns import qn
import os

# ── Constants ──────────────────────────────────────────
W, H = Inches(13.333), Inches(7.5)          # 16:9, ~1920×1080
PAD_X = Inches(0.833)                       # 120px equiv
CREAM    = RGBColor(0xEF, 0xE7, 0xD4)
CREAM2   = RGBColor(0xE6, 0xDC, 0xC4)
GREEN    = RGBColor(0x2E, 0x4A, 0x2A)
GREEN_DEEP = RGBColor(0x24, 0x3A, 0x21)
INK      = RGBColor(0x1A, 0x1A, 0x17)
PINK     = RGBColor(0xE8, 0x9C, 0xB1)

TOTAL = 20
prs = Presentation()
prs.slide_width  = W
prs.slide_height = H

blank = prs.slide_layouts[6]  # blank layout

# ── Helpers ────────────────────────────────────────────

def new_slide(bg_hex):
    """Create a new slide with solid background + fade transition."""
    slide = prs.slides.add_slide(blank)
    bg = slide.background
    fill = bg.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor.from_string(bg_hex)
    # Fade transition via XML (python-pptx 1.0.x compat)
    # spd: transition speed (slow/med/fast); thruBlk: 0=crossfade, 1=fade-through-black
    transition = etree.SubElement(slide._element, qn('p:transition'))
    transition.set('spd', 'slow')
    fade = etree.SubElement(transition, qn('p:fade'))
    fade.set('thruBlk', '0')
    return slide

def px(val):
    return Inches(val / 72)

def rect(slide, x, y, w, h, fill=None, line=None, line_w=0, shape=MSO_SHAPE.RECTANGLE):
    sp = slide.shapes.add_shape(shape, px(x), px(y), px(w), px(h))
    sp.line.fill.background()
    if fill:
        sp.fill.solid()
        sp.fill.fore_color.rgb = fill
    if line:
        sp.line.fill.solid()
        sp.line.color.rgb = line
        sp.line.width = Pt(line_w)
    else:
        sp.line.fill.background()
    return sp

def textbox(slide, x, y, w, h):
    sp = slide.shapes.add_textbox(px(x), px(y), px(w), px(h))
    return sp.text_frame

def para(tf, bold=False, size=30, color=INK, spacing=1.15, align=PP_ALIGN.LEFT,
         space_before=0, space_after=0, mono=False, em=0):
    p = tf.add_paragraph()
    p.font.size = Pt(size)
    p.font.color.rgb = color
    p.font.bold = bold
    p.line_spacing = Pt(size * spacing)
    p.space_before = Pt(space_before)
    p.space_after = Pt(space_after)
    p.alignment = align
    if mono:
        p.font.name = 'JetBrains Mono'
    else:
        p.font.name = 'Source Serif 4'
    return p

def add_run(p, text, size=None, color=None, bold=False, mono=False, em=0):
    run = p.add_run()
    run.text = text
    if size: run.font.size = Pt(size)
    if color: run.font.color.rgb = color
    if bold: run.font.bold = True
    if mono: run.font.name = 'JetBrains Mono'
    return run

def topbar(slide, label, counter, color=GREEN, extra=None):
    tf = textbox(slide, 120, 48, 1680, 36)
    p = para(tf, size=26, color=color, mono=True, em=0.18)
    add_run(p, label)
    if extra:
        add_run(p, '    ' + extra, color=color)
    tf2 = textbox(slide, 1440, 48, 360, 36)
    p2 = para(tf2, size=24, color=color, align=PP_ALIGN.RIGHT, mono=True, em=0.14)
    add_run(p2, counter)

def footline(slide, left, right, color=GREEN):
    tf = textbox(slide, 120, 1016, 900, 24)
    p = para(tf, size=24, color=color, mono=True, em=0.14)
    add_run(p, left)
    tf2 = textbox(slide, 1080, 1016, 720, 24)
    p2 = para(tf2, size=24, color=color, align=PP_ALIGN.RIGHT, mono=True, em=0.14)
    add_run(p2, right)

def shape_text(shape):
    return shape.text_frame

def fill_alpha(shape, alpha_pct):
    """Set fill alpha for a shape via lxml."""
    solid = shape._element.find(qn('p:spPr')).find(qn('a:solidFill'))
    if solid is None:
        solid = shape._element.find(qn('p:spPr')).find(qn('a:grpFill'))
    if solid is None: return
    # Find existing srgbClr or create wrapper
    srgb = solid.find(qn('a:srgbClr'))
    if srgb is None:
        # Convert hex fill to srgbClr
        fill_elem = solid
        srgb = fill_elem.makeelement(qn('a:srgbClr'), {'val': '000000'})
        alpha = srgb.makeelement(qn('a:alpha'), {'val': str(int(alpha_pct * 1000))})
        srgb.append(alpha)
        fill_elem.append(srgb)
    else:
        alpha = srgb.makeelement(qn('a:alpha'), {'val': str(int(alpha_pct * 1000))})
        srgb.append(alpha)

def add_notes(slide, text, time_est=''):
    """Add speaker notes to a slide."""
    notes_slide = slide.notes_slide
    tf = notes_slide.notes_text_frame
    tf.clear()
    if time_est:
        p = tf.paragraphs[0]
        p.text = '⏱ ' + time_est
        p.font.size = Pt(14)
        p.font.color.rgb = GREEN
        p.font.name = 'JetBrains Mono'
        p2 = tf.add_paragraph()
        p2.text = text
        p2.font.size = Pt(14)
        p2.font.color.rgb = INK
        p2.font.name = 'Source Serif 4'
    else:
        p = tf.paragraphs[0]
        p.text = text
        p.font.size = Pt(14)
        p.font.color.rgb = INK
        p.font.name = 'Source Serif 4'


# ═══════════════════════════════════════════════════════
# SLIDE 1 — 封面
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'COMPARATIVE POLITICS', '01 / 20', GREEN)
tf = textbox(s, 120, 160, 700, 36)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.18), 'BRITAIN & AMERICA')
tf = textbox(s, 120, 210, 1680, 220)
add_run(para(tf, size=220, color=GREEN, bold=False, spacing=0.92), '英美两党制')
tf = textbox(s, 120, 460, 1400, 80)
add_run(para(tf, size=80, color=INK, bold=False, spacing=1.0), '历史溯源 · 制度比较 · 批判审视')
tf = textbox(s, 120, 570, 700, 44)
add_run(para(tf, size=30, color=GREEN), '从威斯敏斯特到国会山，两种政党制度的演化路径与当代形态')
tf = textbox(s, 120, 660, 500, 44)
p = para(tf, size=30, color=INK, align=PP_ALIGN.CENTER)
add_run(p, '汇报人  ', size=24, color=GREEN, mono=True, em=0.14)
add_run(p, '董可琪')
footline(s, '英美两党制比较研究', '01 / 20')
add_notes(s, '欢迎大家。今天我要和大家分享的是英美两党制的比较研究。从历史溯源、制度比较、批判审视三个维度，理解这两种最具代表性的两党制模式。整个分享约19分钟，之后欢迎大家提问交流。', '约 30 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 2 — 视频占位
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'VIDEO', '02 / 20', GREEN)
rect(s, 240, 210, 1440, 640, line=GREEN, line_w=3, shape=MSO_SHAPE.RECTANGLE)
tf = textbox(s, 240, 440, 1440, 120)
p = para(tf, size=84, color=GREEN, align=PP_ALIGN.CENTER, spacing=0.96)
add_run(p, '在此插入视频')
tf = textbox(s, 240, 540, 1440, 60)
p = para(tf, size=30, color=INK, align=PP_ALIGN.CENTER)
add_run(p, '建议插入内容：英美两党制概述或选举制度可视化短片')
add_notes(s, '首先让我们看一段短片，大约2分钟，对英美两党制有一个直观的了解。请播放视频。', '约 2 分钟（视频）')


# ═══════════════════════════════════════════════════════
# SLIDE 3 — 目录
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'AGENDA', '03 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '内容纲要')
tiles = [
    ('PART 01', '制度溯源', '英国议会主权与美国总统制各自的历史形成路径', GREEN, CREAM),
    ('PART 02', '政党格局', '保守党与工党、民主党与共和党——两大阵营的百年演进', GREEN_DEEP, GREEN_DEEP),
    ('PART 03', '比较分析', '选举制度、政党组织、意识形态光谱的多维度对比', RGBColor(0xC2, 0x7A, 0x54), CREAM),
    ('PART 04', '评价反思', '两党制的制度优势、内在局限及当代挑战', RGBColor(0x5B, 0x7A, 0x7A), CREAM),
]
for i, (num, title, desc, tcolor, bgc) in enumerate(tiles):
    x = 120 + (i % 2) * 860
    y = 330 + (i // 2) * 280
    sp = rect(s, x, y, 810, 240, fill=bgc, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40)
    tf2.margin_top = px(40)
    if i == 1:
        sp.fill.solid(); sp.fill.fore_color.rgb = PINK
    add_run(para(tf2, size=24, color=tcolor, mono=True, em=0.14, space_before=0), num)
    add_run(para(tf2, size=56, color=tcolor, spacing=0.98, space_before=10), title)
    add_run(para(tf2, size=26, color=tcolor if i else CREAM, spacing=1.34, space_before=8), desc)
add_notes(s, '好，看完视频我们来看今天的分享结构，分为四个部分：制度溯源、政党格局、比较分析、评价反思。每一部分都会用对比的方式呈现英美两国的异同。请大家先有个整体印象。', '约 30 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 4 — 导言
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'INTRODUCTION', '04 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '什么是两党制')

# Two cards
for i, (tag, title, body) in enumerate([
    ('DEFINITION', '定义', '两党制指两个主要政党在国家政治中占据支配地位的政党制度。尽管小党存在，但两大党交替执政，选民的注意力与政治资源高度集中于二者之间。'),
    ('MECHANISM', '形成机制', '单一选区相对多数制（FPTP）是两党制最核心的制度推手。社会学中的「杜瓦杰定律」指出：单选区简单多数制倾向于产生两党制。'),
]):
    sp = rect(s, 120 + i * 870, 340, 810, 340, fill=CREAM2, line=GREEN, line_w=2.5, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(32); tf2.margin_top = px(40)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.14, space_before=0), tag)
    add_run(para(tf2, size=68, color=GREEN, spacing=0.96, space_before=8), title)
    add_run(para(tf2, size=30, color=INK, spacing=1.4, space_before=10), body)

# Bottom bar
rect(s, 120, 730, 1680, 0, line=GREEN, line_w=3)
items = [('核心特征', '两大党合计得票率通常超过 80%'), ('典型国家', '英国 · 美国 · 加拿大 · 澳大利亚'), ('制度后果', '政治稳定 · 责任清晰 · 选择有限')]
for i, (label, value) in enumerate(items):
    x = 120 + i * 580
    tf = textbox(s, x, 750, 540, 36)
    add_run(para(tf, size=24, color=GREEN, mono=True, em=0.14, space_before=0), label)
    tf = textbox(s, x, 790, 540, 44)
    add_run(para(tf, size=30, color=INK, spacing=1.3, space_before=4), value)
add_notes(s, '什么是两党制？两个主要政党在国家政治中占据支配地位。最核心的制度推力是单一选区相对多数制——杜瓦杰定律。两大党合计得票率通常超过80%。典型国家除英美外还有加拿大和澳大利亚。三个制度后果——政治稳定、责任清晰、选择有限——这是今天反复讨论的核心张力。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 5 — 英国制度溯源 (bg-green)
# ═══════════════════════════════════════════════════════
s = new_slide('2E4A2A')
topbar(s, 'UK ORIGINS', '05 / 20', PINK)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=CREAM, spacing=0.96), '英国政党政治的千年演化')
uk_evts = [
    ('1215', '大宪章', '确立王在法下原则，贵族以议会为平台制衡王权，为政党政治奠定制度空间。'),
    ('1688', '光荣革命', '确立议会主权，托利党与辉格党的分野正式进入议会政治舞台。'),
    ('1832', '改革法案', '扩大选举权，政党从议会内精英俱乐部走向全国性群众组织。'),
    ('1924', '工党执政', '自由党衰落，工党取代其地位，现代保守党—工党两党格局定型。'),
]
for i, (year, title, body) in enumerate(uk_evts):
    sp = rect(s, 120 + i * 430, 340, 400, 420, fill=GREEN_DEEP, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(36); tf2.margin_top = px(44)
    add_run(para(tf2, size=56, color=PINK, spacing=0.96, space_before=0), year)
    add_run(para(tf2, size=30, color=CREAM, spacing=1.35, space_before=10),
            '\u2003'.join([title, body]))
# Bottom
rect(s, 120, 800, 1680, 0, line=PINK, line_w=3)
tf = textbox(s, 120, 830, 1600, 88)
p = para(tf, size=30, color=CREAM, spacing=1.35)
add_run(p, '关键转折：', size=30, color=PINK, bold=True)
add_run(p, '英国的两党制并非一蹴而就。从 17 世纪的托利 vs 辉格，到 19 世纪的保守 vs 自由，再到 20 世纪的保守 vs 工党——政党更替本身即是一部社会力量重组的历史。')
footline(s, '英国政党制度的历史演进', 'BRITISH POLITICAL HISTORY', PINK)
add_notes(s, '英国两党制有近千年演化历史。1215大宪章确立王在法下，1688光荣革命确立议会主权，1832改革法案扩大选举权，1924工党执政定型现代格局。每一次重大选民扩容都重塑了政党格局，英国政党更替本身就是社会力量重组的历史。演化路径和美国完全不同——英国政党是从议会内生出来的。', '约 90 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 6 — 威斯敏斯特宫 (dark bg placeholder for image)
# ═══════════════════════════════════════════════════════
s = new_slide('3A4A3A')
topbar(s, 'WESTMINSTER', '06 / 20', CREAM)
tf = textbox(s, 120, 860, 860, 160)
add_run(para(tf, size=24, color=CREAM, mono=True, em=0.18), 'HOUSES OF PARLIAMENT')
add_run(para(tf, size=84, color=CREAM, spacing=0.96, space_before=8), '威斯敏斯特宫')
tf = textbox(s, 120, 740, 700, 100)
p = para(tf, size=32, color=CREAM, spacing=1.35)
add_run(p, '英国议会所在地，议会主权的物质象征。下议院绿色长椅上的执政党与反对党面对面而坐——空间设计本身就编码了对抗性的两党政治文化。')
add_notes(s, '这是威斯敏斯特宫。注意它的建筑设计：下议院绿色长椅，执政党与反对党面对面而坐。空间设计本身就编码了对抗性的两党政治文化。对比后面会看到的美国国会大厦，坐席布局完全不同——一个是面对面对抗，一个是讲台式布局。', '约 30 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 7 — 英国两党格局
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'UK PARTIES', '07 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=GREEN, spacing=0.96), '保守党与工党：英国的两极')
parties = [
    ('CONSERVATIVE PARTY', '保守党', '前身为 17 世纪的托利党，1834 年正式定名。代表传统中右立场：市场经济、个人责任、维护君主制与联合王国统一。标志色为蓝色，绰号「托利」（Tories）。', ['成立：1834', '党魁：现任首相']),
    ('LABOUR PARTY', '工党', '1900 年由工会运动与社会主义团体联合创立。代表中左立场：社会福利、公共支出、工人权益。标志色为红色，20 世纪 20 年代取代自由党成为主要反对党。', ['成立：1900', '根基：工会运动']),
]
for i, (en, cn, body, metas) in enumerate(parties):
    sp = rect(s, 120 + i * 870, 330, 810, 560, fill=CREAM2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(44); tf2.margin_top = px(48)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.14), en)
    add_run(para(tf2, size=56, color=GREEN, spacing=0.96, space_before=8), cn)
    add_run(para(tf2, size=30, color=INK, spacing=1.4, space_before=10), body)
    p = para(tf2, space_before=16)
    add_run(p, '\u3000\u3000'.join(metas), size=24, color=GREEN, mono=True, em=0.08)
footline(s, '英国的两大政党', 'CONSERVATIVE & LABOUR')
add_notes(s, '英国的两大政党。保守党前身托利党、1834年定名，代表中右立场。工党1900年由工会创立，代表中左立场。保守党标志色蓝色、绰号Tories；工党标志色红色。20世纪20年代工党取代自由党成为主要反对党，这是英国政党格局的关键转折。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 8 — 美国制度溯源
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'US ORIGINS', '08 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '从联邦党人到现代两党')
us_evts = [
    ('1787 – 1824', '建国初的分野', '联邦党人（Hamilton）vs 民主共和党人（Jefferson）：围绕联邦权力、经济政策与对英对法外交的路线之争。'),
    ('1828 – 1854', '杰克逊时代', '民主党的前身——杰克逊民主党崛起，辉格党作为反对派形成。大众民主时代开启：选举权向无产白人男性扩展。'),
    ('1854 – 1896', '共和党的诞生', '奴隶制争议撕裂辉格党，共和党以反奴隶制扩张为旗帜成立。林肯当选加速南北战争，确立共和党主导地位。'),
    ('1896 – 至今', '现代两党定型', '进步时代、新政联盟、民权运动依次重塑两党选民基础。20 世纪 60 年代后形成今日民主vs共和的意识形态格局。'),
]
for i, (tag, title, body) in enumerate(us_evts):
    sp = rect(s, 120 + i * 430, 340, 400, 470, fill=CREAM2, line=GREEN, line_w=2.5, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(32); tf2.margin_top = px(40)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.14), tag)
    add_run(para(tf2, size=68, color=GREEN, spacing=0.96, space_before=8), title)
    add_run(para(tf2, size=30, color=INK, spacing=1.35, space_before=10), body)
# Bottom note
rect(s, 120, 850, 1680, 0, line=GREEN, line_w=3)
tf = textbox(s, 120, 880, 1600, 88)
p = para(tf, size=30, color=INK, spacing=1.35)
add_run(p, '与美国制度的共生：', size=30, color=GREEN, bold=True)
add_notes(s, '美国的政党演化分四个阶段。建国初分野——联邦党人vs民主共和党人；杰克逊时代——大众民主开启；共和党诞生——林肯当选加速南北战争；现代两党定型——新政联盟和民权运动重塑选民基础。关键不同：美国政党从未被宪法明文提及，在权力制衡空隙中自发生长——外生型政党，和英国内生型完全不同。', '约 90 秒')

add_run(p, '美国的政党体系与其总统制、联邦制、三权分立深度耦合。政党从未被宪法明文提及——它们是在权力制衡的空隙中自发生长出来的组织形态。')

# ═══════════════════════════════════════════════════════
# SLIDE 9 — 美国国会大厦 (dark bg placeholder for image)
# ═══════════════════════════════════════════════════════
s = new_slide('4A5A4A')
topbar(s, 'CAPITOL HILL', '09 / 20', CREAM)
tf = textbox(s, 120, 860, 860, 160)
add_run(para(tf, size=24, color=CREAM, mono=True, em=0.18), 'UNITED STATES CAPITOL')
add_run(para(tf, size=84, color=CREAM, spacing=0.96, space_before=8), '国会大厦')
tf = textbox(s, 120, 740, 700, 100)
p = para(tf, size=32, color=CREAM, spacing=1.35)
add_run(p, '美国立法权的物理象征，新古典主义穹顶下分列参众两院。与威斯敏斯特的对抗式坐席不同，美国国会的半圆形议场反映了更复杂的党派协商空间。')
add_notes(s, '美国国会大厦。半圆形议场和威斯敏斯特对抗式坐席完全不同。新古典主义建筑传达共和理念——权力来自人民而非君主。国会两院分立互相制衡，使得政党很难像英国那样实现行政立法完全统一。', '约 30 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 10 — 美国两党格局 (bg-green)
# ═══════════════════════════════════════════════════════
s = new_slide('2E4A2A')
topbar(s, 'US PARTIES', '10 / 20', PINK)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=CREAM, spacing=0.96), '民主党与共和党：美国的两极')
us_parties = [
    ('DEMOCRATIC PARTY', '民主党', '前身为杰斐逊的民主共和党，1828 年杰克逊时代正式定名。现代民主党代表中左立场：社会包容、政府干预经济、进步主义社会政策。标志色为蓝色，象征物为驴。', ['成立：1828', '象征：驴']),
    ('REPUBLICAN PARTY', '共和党', '1854 年以反奴隶制扩张为旗帜成立。现代共和党代表中右立场：有限政府、自由市场、传统价值观、强国防。标志色为红色，象征物为象，绰号「大老党」(GOP)。', ['成立：1854', '象征：象']),
]
for i, (en, cn, body, metas) in enumerate(us_parties):
    sp = rect(s, 120 + i * 870, 330, 810, 560, fill=GREEN_DEEP, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(44); tf2.margin_top = px(48)
    add_run(para(tf2, size=24, color=PINK, mono=True, em=0.14), en)
    add_run(para(tf2, size=56, color=PINK, spacing=0.96, space_before=8), cn)
    add_run(para(tf2, size=30, color=CREAM, spacing=1.4, space_before=10), body)
    p = para(tf2, space_before=16)
    add_run(p, '\u3000\u3000'.join(metas), size=24, color=PINK, mono=True, em=0.08)
footline(s, '美国的两大政党', 'DEMOCRATIC & REPUBLICAN', PINK)
add_notes(s, '民主党1828年定名、象征驴，代表中左。共和党1854年成立、象征象、绰号GOP大老党，代表中右。民主党强调社会包容和政府干预，共和党强调有限政府和自由市场。和英国相比，美国两党意识形态距离大得多，极化也严重得多。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 11 — 制度对比 (TABLE)
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'COMPARISON', '11 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '英美两党制比较')

rows = [
    ('维度', '英国两党制', '美国两党制'),
    ('体制基础', '议会内阁制、行政立法合一', '总统制、三权分立'),
    ('执政标志', '议会下院多数席位\n独特的反对党制度', '赢得总统大选\n不存在在野党与执政党严格区分'),
    ('选举核心', '议会选举', '总统选举'),
    ('组织政府', '实行相容制', '不相容制'),
    ('政党纪律', '集中严格', '松散，无强制约束'),
]
tbl = s.shapes.add_table(len(rows), 3, px(120), px(340), px(1680), px(72 * len(rows)))
for r, (c1, c2, c3) in enumerate(rows):
    for c, val in enumerate([c1, c2, c3]):
        cell = tbl.table.cell(r, c)
        cell.text = ''
        p = cell.text_frame.paragraphs[0]
        p.font.size = Pt(30 if r > 0 else 24)
        p.font.color.rgb = GREEN if r == 0 or c == 0 else INK
        p.font.name = 'JetBrains Mono' if (r == 0 or c == 0) else 'Source Serif 4'
        run = p.add_run()
        run.text = val
        cell.margin_left = px(28)
        cell.margin_top = px(12 if r == 0 else 18)
    # Bottom border
    if r == 0:
        for c in range(3):
            cell = tbl.table.cell(r, c)
            tcPr = cell._tc.get_or_add_tcPr()
            lnB = tcPr.makeelement(qn('a:lnB'), {'w': '25000'})
            solidFill = lnB.makeelement(qn('a:solidFill'), {})
            srgb = solidFill.makeelement(qn('a:srgbClr'), {'val': '2E4A2A'})
            solidFill.append(srgb)
            lnB.append(solidFill)
            tcPr.append(lnB)
tbl.table.columns[0].width = px(240)
tbl.table.columns[1].width = px(720)
tbl.table.columns[2].width = px(720)
add_notes(s, '核心对比表。五个维度：体制基础——议会内阁制vs总统制；执政标志——英国有独特反对党制度（影子内阁、官方反对党领袖），美国没有在野党执政党严格区分；选举核心——议会选举vs总统选举；组织政府——相容制vs不相容制；政党纪律——集中严格vs松散。这五个维度是理解两国差异的框架。', '约 90 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 12 — 政党组织对比
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'ORGANIZATION', '12 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '政党组织形态的差异')
org_cards = [
    ('UNITED KINGDOM', '强党鞭 · 高纪律', '议会党团高度集权。党鞭制度确保议员按党派立场投票，跨党派投票极为罕见。候选人由党中央筛选，地方党组织权力有限。',
     [('中央提名', GREEN, CREAM), ('党鞭约束', GREEN, CREAM), ('集体责任', GREEN, CREAM)]),
    ('UNITED STATES', '弱党鞭 · 高自主', '国会党团纪律松散。议员优先回应选区选民而非党派领导。初选制度让候选人绕过党组织直接诉诸选民，个人政治品牌往往凌驾政党标签之上。',
     [('初选决定', CREAM2, GREEN), ('选区自主', CREAM2, GREEN), ('跨党投票', CREAM2, GREEN)]),
]
for i, (label, title, body, tags) in enumerate(org_cards):
    sp = rect(s, 120 + i * 870, 340, 810, 480, line=GREEN, line_w=3, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(44)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.18), label)
    add_run(para(tf2, size=56, color=GREEN, spacing=0.96, space_before=8), title)
    add_run(para(tf2, size=30, color=INK, spacing=1.35, space_before=12), body)
    # Tags
    for j, (tag_text, tbg, tc) in enumerate(tags):
        tag_sp = rect(s, 160 + i * 870 + j * 180, 700, 160, 44, fill=tbg, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        if tc == GREEN and tbg == CREAM2:
            tag_sp.line.fill.solid(); tag_sp.line.color.rgb = GREEN; tag_sp.line.width = Pt(2)
        ttf = shape_text(tag_sp)
        ttf.margin_left = px(10); ttf.margin_top = px(4)
        add_run(para(ttf, size=24, color=tc, mono=True, em=0.08), tag_text)

# Bottom
rect(s, 120, 860, 1680, 0, line=GREEN, line_w=2)
tf = textbox(s, 120, 890, 1600, 88)
p = para(tf, size=30, color=INK, spacing=1.35)
add_run(p, '根源在于制度逻辑：', size=30, color=GREEN, bold=True)
add_run(p, '议会制要求行政与立法合一，政党纪律是执政前提；总统制天然分立，议员个人权力来自独立选举而非政党领袖恩赐。两种组织形态是各自宪法架构的函数。')
add_notes(s, '政党组织形态的差异。英国强党鞭高纪律，议会党团高度集权，跨党派投票极为罕见。美国弱党鞭高自主，议员优先回应选区选民。根源在制度逻辑：议会制要求行政立法合一，政党纪律是执政前提；总统制天然分立，议员权力来自独立选举。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 13 — 提名机制对比
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'NOMINATION', '13 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '候选人提名机制差异')
nom_cards = [
    ('UNITED KINGDOM', '党组织主导 · 自上而下', '议会候选人由地方选区政党协会筛选、党中央审核确认，提名权牢牢掌握在政党组织手中。个人脱离政党资源与组织渠道，几乎不可能独立参选获胜，候选人高度依附政党意志。',
     [('中央审核', GREEN, CREAM), ('党控提名', GREEN, CREAM), ('依附政党', GREEN, CREAM)]),
    ('UNITED STATES', '选民主导 · 自下而上', '独创党内初选制度，总统及议员候选人由本党注册选民投票选出，政党高层无权干预、无法指定人选。候选人依赖个人竞选团队与私人筹款，个人品牌往往凌驾政党标签之上。',
     [('初选决定', CREAM2, GREEN), ('个人筹款', CREAM2, GREEN), ('政党为平台', CREAM2, GREEN)]),
]
for i, (label, title, body, tags) in enumerate(nom_cards):
    sp = rect(s, 120 + i * 870, 340, 810, 480, line=GREEN, line_w=3, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(44)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.18), label)
    add_run(para(tf2, size=56, color=GREEN, spacing=0.96, space_before=8), title)
    add_run(para(tf2, size=30, color=INK, spacing=1.35, space_before=12), body)
    for j, (tag_text, tbg, tc) in enumerate(tags):
        tag_sp = rect(s, 160 + i * 870 + j * 180, 700, 160, 44, fill=tbg, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        if tc == GREEN and tbg == CREAM2:
            tag_sp.line.fill.solid(); tag_sp.line.color.rgb = GREEN; tag_sp.line.width = Pt(2)
        ttf = shape_text(tag_sp)
        ttf.margin_left = px(10); ttf.margin_top = px(4)
        add_run(para(ttf, size=24, color=tc, mono=True, em=0.08), tag_text)
rect(s, 120, 860, 1680, 0, line=GREEN, line_w=2)
tf = textbox(s, 120, 890, 1600, 88)
p = para(tf, size=30, color=INK, spacing=1.35)
add_run(p, '提名逻辑反映政党本质：', size=30, color=GREEN, bold=True)
add_notes(s, '候选人提名机制的差异。英国党组织主导、自上而下，候选人由党中央筛选审核，几乎不可能脱离政党独立参选。美国选民主导、自下而上，独创初选制度——候选人由本党注册选民投票选出，政党高层无权干预。政治权力从政党转移到个人。特朗普能赢得共和党提名，在英国体制下难以想象。', '约 60 秒')

add_run(p, '英国政党是治理工具，候选人依附组织意志；美国政党是竞选平台，候选人个人才是政治主角。两种提名模式是各自宪政生态的产物。')

# ═══════════════════════════════════════════════════════
# SLIDE 14 — 立法运作对比
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'LEGISLATION', '14 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '议会立法运作差异')
leg_cards = [
    ('UNITED KINGDOM', '执政党主导 · 行政立法合一', '执政党掌握下议院多数，内阁主导法案起草与政策规划。依托严格党纪，执政党法案通过率极高，反对党主要承担质询监督、舆论制衡功能，难以阻挡核心政策落地。',
     [('内阁主导', GREEN, CREAM), ('高通过率', GREEN, CREAM), ('程序制衡', GREEN, CREAM)]),
    ('UNITED STATES', '立法独立 · 多重制衡', '国会是独立立法机关，总统无权直接提交法案、无权解散国会。参众两院相互制衡，政党控制力薄弱。即使总统与国会同党，议员仍可基于选区利益拒绝配合，立法过程缓慢、博弈激烈。',
     [('国会独立', CREAM2, GREEN), ('两院制衡', CREAM2, GREEN), ('博弈缓慢', CREAM2, GREEN)]),
]
for i, (label, title, body, tags) in enumerate(leg_cards):
    sp = rect(s, 120 + i * 870, 340, 810, 480, line=GREEN, line_w=3, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(44)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.18), label)
    add_run(para(tf2, size=56, color=GREEN, spacing=0.96, space_before=8), title)
    add_run(para(tf2, size=30, color=INK, spacing=1.35, space_before=12), body)
    for j, (tag_text, tbg, tc) in enumerate(tags):
        tag_sp = rect(s, 160 + i * 870 + j * 180, 700, 160, 44, fill=tbg, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
        if tc == GREEN and tbg == CREAM2:
            tag_sp.line.fill.solid(); tag_sp.line.color.rgb = GREEN; tag_sp.line.width = Pt(2)
        ttf = shape_text(tag_sp)
        ttf.margin_left = px(10); ttf.margin_top = px(4)
        add_run(para(ttf, size=24, color=tc, mono=True, em=0.08), tag_text)
rect(s, 120, 860, 1680, 0, line=GREEN, line_w=2)
tf = textbox(s, 120, 890, 1600, 88)
p = para(tf, size=30, color=INK, spacing=1.35)
add_run(p, '议会运作反映权力逻辑：', size=30, color=GREEN, bold=True)
add_notes(s, '议会立法运作也有根本不同。英国执政党主导，内阁起草法案，党纪保障高通过率。美国立法独立，国会是独立立法机关，总统无权提交法案和解散国会。英国立法是执政工具高效产出，美国立法是博弈场域制衡优先。即使总统与国会同党，议员仍可基于选区利益拒绝配合。', '约 60 秒')

add_run(p, '英国立法是执政工具、高效产出；美国立法是博弈场域、制衡优先。两种立法模式分别服务于议会主权与三权分立的宪政架构。')

# ═══════════════════════════════════════════════════════
# SLIDE 15 — 制度根源 (bg-green)
# ═══════════════════════════════════════════════════════
s = new_slide('2E4A2A')
topbar(s, 'ROOTS', '15 / 20', CREAM)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=CREAM, spacing=0.96), '差异的深层制度根源')
roots = [
    ('01 · 政体结构', '英国议会内阁制实现立法行政一体化，政党必须团结维系政府；美国总统制三权分立，权力相互独立，天然弱化政党整合功能。'),
    ('02 · 政党生成逻辑', '英国政党诞生于议会治理需求（内生型）；美国政党诞生于大选动员需求（外生型）。生成路径决定组织基因。'),
    ('03 · 政治责任对象', '英国议员对党和政府负责，纪律是生存前提；美国议员对选区选民负责，个人权力来自独立选举而非政党领袖恩赐。'),
    ('04 · 选举制度', '英国以政党为选举主体，集体标签决定胜负；美国以候选人为选举主体，个人魅力与选区认同超越党派归属。'),
]
for i, (title, body) in enumerate(roots):
    x, y = 120 + (i % 2) * 870, 340 + (i // 2) * 260
    sp = rect(s, x, y, 810, 220, fill=GREEN_DEEP, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(44)
    add_run(para(tf2, size=24, color=PINK, mono=True, em=0.18), title)
    add_run(para(tf2, size=30, color=CREAM, spacing=1.35, space_before=8), body)
add_notes(s, '四个深层制度根源。政体结构、政党生成逻辑、政治责任对象、选举制度。英国内生型政党对党和政府负责，以政党为选举主体；美国外生型政党对选区选民负责，以候选人为选举主体。这些差异不是偶然的，是各自宪法架构的函数。理解这个，就能理解前面所有的差异。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 16 — 选举制度比较
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'ELECTORAL SYSTEMS', '16 / 20', GREEN, extra='选举制度的异同')
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=GREEN, spacing=0.96), '选举制度：共同逻辑与关键分歧')
el_cards = [
    ('COMMON GROUND', '共同基础', ['单一选区相对多数制（FPTP）是两国选区制度的核心共同点', '赢者通吃的逻辑天然压制第三党，是两党制持续的制度根基', '选区划分对选举结果有重大影响——英国的边界委员会与美国的选区重划均有争议']),
    ('KEY DIVERGENCES', '关键分歧', ['行政选举：英国议会选举间接产生首相；美国总统由选举人团独立选举', '选举节奏：英国大选不固定（最长五年）vs 美国严格固定周期', '初选制度：美国有公开初选；英国候选人由党内封闭遴选']),
]
for i, (tag, title, items) in enumerate(el_cards):
    sp = rect(s, 120 + i * 870, 330, 810, 430, fill=CREAM2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(44); tf2.margin_top = px(48)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.14), tag)
    add_run(para(tf2, size=56, color=GREEN, spacing=0.96, space_before=8), title)
    for it in items:
        add_run(para(tf2, size=30, color=INK, spacing=1.35, space_before=8), it)
# Stats
rect(s, 120, 820, 1680, 0, line=GREEN, line_w=2)
stats = [('UK LOWER HOUSE', '650 个选区', '下议院议席'), ('US ELECTORAL COLLEGE', '538 张选举人票', '270 票当选'), ('US CONGRESS', '435 + 100', '众议院 + 参议院')]
for i, (tag, big, small) in enumerate(stats):
    x = 120 + i * 580
    tf = textbox(s, x, 840, 540, 36)
    add_run(para(tf, size=24, color=GREEN, mono=True, em=0.14), tag)
    tf = textbox(s, x, 878, 540, 66)
    add_run(para(tf, size=56, color=GREEN, spacing=0.96), big)
    tf = textbox(s, x, 946, 540, 44)
    add_run(para(tf, size=30, color=INK), small)
add_notes(s, '选举制度比较。共同基础是FPTP单一选区相对多数制，赢者通吃压制第三党。关键分歧：英国议会选举间接产生首相，美国总统由选举人团独立选举。数据：英国下院650席，美国选举人团538票、270当选，国会435众+100参。英国大选不固定最长五年一选；美国选举周期严格固定。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 17 — 意识形态光谱
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'IDEOLOGY', '17 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '意识形态光谱与政策定位')

# Spectrum labels
tf = textbox(s, 120, 340, 540, 36)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.08), 'LEFT 左翼')
tf = textbox(s, 880, 340, 300, 36)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.08, align=PP_ALIGN.CENTER), 'CENTER 中间')
tf = textbox(s, 1500, 340, 300, 36)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.08, align=PP_ALIGN.RIGHT), 'RIGHT 右翼')

# Spectrum bar bg + UK positioning
rect(s, 120, 390, 1680, 120, fill=CREAM2)
ov_l = rect(s, 120, 390, 560, 120, fill=PINK)
fill_alpha(ov_l, 35)
ov_r = rect(s, 1120, 390, 680, 120, fill=PINK)
fill_alpha(ov_r, 35)
# UK labels
tf = textbox(s, 160, 410, 400, 50)
add_run(para(tf, size=30, color=GREEN_DEEP, bold=True), '英国工党 LABOUR')
tf = textbox(s, 1160, 410, 400, 50)
add_run(para(tf, size=30, color=GREEN_DEEP, bold=True), '英国保守党 CONSERVATIVE')

# US party positions
rect(s, 120, 540, 1680, 120, fill=CREAM2)
# US spectrum bar
us_l = rect(s, 200, 540, 640, 120, fill=RGBColor(0x3A, 0x4A, 0x3A))
fill_alpha(us_l, 45)
us_r = rect(s, 960, 540, 720, 120, fill=RGBColor(0x4A, 0x3A, 0x3A))
fill_alpha(us_r, 45)
tf = textbox(s, 240, 560, 400, 50)
add_run(para(tf, size=30, color=INK, bold=True), '美国民主党 DEMOCRATIC')
tf = textbox(s, 1000, 560, 400, 50)
add_run(para(tf, size=30, color=INK, bold=True), '美国共和党 REPUBLICAN')

# Policy comparison
tf = textbox(s, 120, 710, 800, 36)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.14), 'POLICY COMPARISON')
tf = textbox(s, 120, 750, 800, 44)
add_run(para(tf, size=56, color=GREEN, spacing=0.96), '核心政策对比')

pol_items = [
    ('税收', '累进税制 · 扩大公共服务', '减税 · 刺激经济增长', '增税 · 调节贫富差距', '减税 · 小政府理念'),
    ('医疗', '单一支付者 NHS 体系', '市场化改革 · 效率优先', '扩大医保覆盖 · ACA', '市场竞争 · 个人选择'),
    ('移民', '积分制 · 技术优先', '控制总量 · 择优录取', '包容多元 · 入籍路径', '边境安全 · 限制非法'),
]
# Mini table
for r, (topic, uk_a, uk_b, us_a, us_b) in enumerate(pol_items):
    y = 820 + r * 60
    tf = textbox(s, 120, y, 180, 36)
    add_run(para(tf, size=24, color=GREEN, mono=True, em=0.08), topic)
    tf = textbox(s, 320, y, 320, 36)
    add_run(para(tf, size=24, color=INK), f'{uk_a}  |  ')
    add_run(tf.paragraphs[0], f'{uk_b}', size=24, color=GREEN)
    tf = textbox(s, 660, y, 320, 36)
    add_run(para(tf, size=24, color=INK), f'{us_a}  |  ')
    add_run(tf.paragraphs[0], f'{us_b}', size=24, color=GREEN)
add_notes(s, '意识形态光谱。用三个政策领域具体化：税收——英国两党都接受累进税制但方向不同，美国两党差异更大；医疗——英国NHS单一支付者体系两党共识高，美国在ACA和市场竞争间反复拉锯；移民——英国积分制两党都强调择优，美国两党差异极大。虽然都是两党制，美国两党意识形态距离明显大于英国。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 18 — 两党制优势 (bg-green)
# ═══════════════════════════════════════════════════════
s = new_slide('2E4A2A')
topbar(s, 'ADVANTAGES', '18 / 20', CREAM)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=CREAM, spacing=0.96), '两党制的制度优势')
adv = [
    ('01 · 政治稳定', '两党交替执政避免多党联合政府的频繁倒阁与政策断裂。英国 1945 年以来内阁平均任期超过 4 年，美国 1789 年以来宪法秩序从未中断，制度延续性远超多数多党制国家。'),
    ('02 · 责任清晰', '选民明确知道谁在执政、谁该负责。相对于多党联合政府的责任模糊与相互推诿，两党制提供了清晰的问责对象：执政党承担施政后果，反对党承担监督责任。'),
    ('03 · 温和中间化', '两党为争取中间选民竞相向政治光谱中心靠拢，抑制极端主义。英国保守党与工党、美国民主党与共和党的政策差异虽明显，但均不会脱离主流民意太远。'),
    ('04 · 治理效率', '单一政党组成的内阁无需跨党谈判，决策链条短、执行力强。在全球危机（疫情、战争、金融危机）中，两党制国家的政府响应速度往往快于多党联合政府。'),
]
for i, (title, body) in enumerate(adv):
    x, y = 120 + (i % 2) * 870, 330 + (i // 2) * 220
    sp = rect(s, x, y, 810, 190, fill=GREEN_DEEP, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(36)
    add_run(para(tf2, size=24, color=PINK, mono=True, em=0.18), title)
    add_run(para(tf2, size=28, color=CREAM, spacing=1.35, space_before=6), body)
add_notes(s, '第四部分评价反思。四个制度优势：政治稳定——英国1945年以来内阁平均任期超4年，美国宪法秩序从未中断；责任清晰——选民明确知道谁执政谁负责；温和中间化——两党向光谱中心靠拢抑制极端主义；治理效率——单一政党内阁决策链条短执行强。这些是多党联合政府难以比拟的。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 19 — 局限与当代挑战
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'CHALLENGES', '19 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=96, color=GREEN, spacing=0.96), '局限与当代挑战')
challenges = [
    ('01 · 选择有限', '两党制压缩政治选择空间。英国自民党、美国绿党与自由党长期处于边缘地位，大量选民的政策偏好无法在两大党中得到充分表达，政治疏离感上升。'),
    ('02 · 极化加剧', '美国两党意识形态极化在过去三十年急剧加深。温和派议员比例从 1990 年代的 40% 降至不足 10%，跨党派合作日益困难，政府停摆与立法僵局频发。'),
    ('03 · 民粹挑战', '英国脱欧公投（2016）和美国特朗普现象（2016-2020）均表明：两党精英无法垄断政治议程。民粹运动绕过既有政党结构直接动员选民，暴露出两党制的代表性危机。'),
    ('04 · 选民冷漠', '英美两国大选投票率长期低于多党制国家（如德国、瑞典）。选举结果可预测性高——大量安全选区缺乏竞争，选民参与动力不足，民主合法性面临挑战。'),
]
for i, (title, body) in enumerate(challenges):
    x, y = 120 + (i % 2) * 870, 330 + (i // 2) * 200
    sp = rect(s, x, y, 810, 170, fill=CREAM2, shape=MSO_SHAPE.ROUNDED_RECTANGLE)
    tf2 = shape_text(sp)
    tf2.margin_left = px(40); tf2.margin_top = px(36)
    add_run(para(tf2, size=24, color=GREEN, mono=True, em=0.18), title)
    add_run(para(tf2, size=28, color=INK, spacing=1.35, space_before=6), body)
add_notes(s, '但局限同样突出。选择有限——大量选民偏好无法在两大党中得到表达；极化加剧——美国温和派议员从1990年代40%降至不足10%；民粹挑战——英国脱欧和美国特朗普现象表明两党精英无法垄断政治议程；选民冷漠——英美投票率长期低于德国瑞典等多党制国家。这些挑战没有任何简单解决方案。', '约 60 秒')


# ═══════════════════════════════════════════════════════
# SLIDE 20 — 结语与参考文献
# ═══════════════════════════════════════════════════════
s = new_slide('EFE7D4')
topbar(s, 'CONCLUSION', '20 / 20', GREEN)
tf = textbox(s, 120, 180, 1400, 110)
add_run(para(tf, size=84, color=GREEN, spacing=0.96), '结语')
tf = textbox(s, 120, 340, 1680, 300)
p = para(tf, size=36, color=INK, spacing=1.5)
add_run(p, '英美两党制既是特定历史路径的产物，也是选举制度的函数。它们在政治稳定、责任清晰与治理效率上各有建树，但也共同面临选择有限、极化加剧与代议危机的当代挑战。理解二者的差异，不仅助于分析西方民主的运作逻辑，也为我们思考政党制度的多元可能提供镜鉴。')

# References
tf = textbox(s, 120, 680, 800, 44)
add_run(para(tf, size=24, color=GREEN, mono=True, em=0.14), 'REFERENCES')
refs = [
    'Duverger, M. (1954). Political Parties. London: Methuen.',
    'Sartori, G. (1976). Parties and Party Systems. Cambridge University Press.',
    'Cox, G. W. (1997). Making Votes Count. Cambridge University Press.',
    'King, A. (2002). The British Constitution. Oxford University Press.',
    'Aldrich, J. H. (2011). Why Parties? A Second Look. University of Chicago Press.',
]
for i, ref in enumerate(refs):
    tf = textbox(s, 120, 730 + i * 36, 1680, 36)
    add_run(para(tf, size=22, color=INK, spacing=1.2, mono=True), ref)

footline(s, '英美两党制比较研究', 'THANK YOU', GREEN)
add_notes(s, '简短总结。英美两党制是特定历史路径和选举制度的共同产物。它们在稳定与效率上各有建树，但共同面临选择有限和极化加剧的当代挑战。理解二者的差异，既助于分析西方民主的运作逻辑，也为我们思考政党制度的多元可能提供镜鉴。谢谢大家，欢迎提问交流。', '约 30 秒')


# ── Save ──────────────────────────────────────────────
os.makedirs('assets', exist_ok=True)
path = 'assets/英美两党制.pptx'
prs.save(path)
print(f'Saved {len(prs.slides)} slides → {path}')
print('所有幻灯片已添加淡出过渡、演讲者备注（总时长约19分钟）。')